# 3D-Ray-tracing-demo

[![Ray tracer](http://img.youtube.com/vi/4ZDDrtbaMfM/0.jpg)](https://www.youtube.com/watch?v=4ZDDrtbaMfM "Python ray tracing")


Requirements: numpy, numba, pygame
To move a scene, you must first reduce the quality of the rendering using the "X" key, then "WASD" for travelling, then several times "Z" for increase rendering quality.
